package Chaining;

import org.testng.annotations.Test;

public class NewTest {

  @Test
  public void DeleteRequestTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void sendGetRequestTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void sendPostBodyTest() {
    throw new RuntimeException("Test not implemented");
  }

  @Test
  public void sendUpdateRequestTest() {
    throw new RuntimeException("Test not implemented");
  }
}
