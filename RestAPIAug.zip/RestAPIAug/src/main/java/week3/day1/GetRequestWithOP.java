package week3.day1;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;


public class GetRequestWithOP {
	
	@Test
	public void sendGetRequestWithQp() {
		
		RestAssured.baseURI = "https://dev62134.service-now.com/api/now/table/incident";
		
		RequestSpecification inputRequest = RestAssured
		.given()
		.auth()
		.basic("admin", "Jl%Ay65ukN!T")
		.queryParam("sysparm_fields", "sys_id, description, category, number");
	
		
		Response  response = inputRequest.get();
		response.prettyPrint();
		System.out.println("Status Code:" + response.statusCode());
	}

}
