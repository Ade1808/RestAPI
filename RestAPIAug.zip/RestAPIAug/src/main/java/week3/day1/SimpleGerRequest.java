package week3.day1;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;


public class SimpleGerRequest {
	
	// 5 step process
	
   // Requirement
  
   
	
	
	@Test
	public void sendGetRequest() {
		 // Endpoint
		RestAssured.baseURI = "https://dev62134.service-now.com/api/now/table/incident";
		
		// Add Request (Authentication + Query Param + Headers + Request Body
		
		RestAssured.authentication = RestAssured.basic("admin", "Jl%Ay65ukN!T");
		
		// Send Request
		
		Response response = RestAssured.get();
		
		// Validate Response
		
		response.prettyPrint();
		System.err.println(response);
		System.out.println("Status code:" + response.statusCode());
		
	}
	

}
