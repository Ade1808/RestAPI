package week3.day1;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UpdateIncident {
	@Test
	public void sendUpdateRequest() {
		
		RestAssured.baseURI = "https://dev62134.service-now.com/api/now/table/incident";
		RequestSpecification inputRequest = RestAssured
		.given()
		.auth()
		.basic("admin", "Jl%Ay65ukN!T")
		.queryParam("sysparm_fields", "sys_id, description, category, number")
		.contentType(ContentType.JSON)
		.accept(ContentType.JSON)
		.body("{\"description\":\"This issue is not from DBMS. The connectivity needs fix\",\"category\":\"Hardware\"}");
		
		Response response = inputRequest.put("94ef18dd1bf111104b168559cc4bcbb7");
		response.then().log().all();
		
	}

}
