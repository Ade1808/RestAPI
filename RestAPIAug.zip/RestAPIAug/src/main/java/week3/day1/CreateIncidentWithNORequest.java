package week3.day1;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncidentWithNORequest {
	@Test
	public void sendGetRequest() {
		
		RestAssured.baseURI = "https://dev62134.service-now.com/api/now/table/incident";
		
		RequestSpecification inputRequest = RestAssured
		.given()
		.auth()
		.basic("admin", "Jl%Ay65ukN!T")
		.queryParam("sysparm_fields", "sys_id, description, category, number")
		.contentType(ContentType.JSON)
		.accept(ContentType.JSON);
		
		
		Response response = inputRequest.post();
		response.prettyPrint();
		System.out.println(response.statusCode());
		String sys_id = response.jsonPath().get("results.sys_id");
		System.out.print("Sys_ID" + sys_id);
	}

}
