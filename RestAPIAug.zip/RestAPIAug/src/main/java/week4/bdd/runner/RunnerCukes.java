package week4.bdd.runner;

import cucumber.api.CucumberOptions;
import io.cucumber.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features = "./src/main/java/week4/bdd/features/IncidentManagement.feature", glue = "week4bdd.implementation")
public class RunnerCukes extends AbstractTestNGCucumberTests {
	
	
	
	

}
