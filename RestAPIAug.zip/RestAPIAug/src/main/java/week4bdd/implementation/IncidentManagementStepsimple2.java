
	package week4bdd.implementation;

	import java.io.File;

import cucumber.api.java.en.And;
	import cucumber.api.java.en.Given;
	import cucumber.api.java.en.Then;
	import cucumber.api.java.en.When;
	import io.restassured.RestAssured;
	import io.restassured.http.ContentType;
	import io.restassured.response.Response;
	import io.restassured.specification.RequestSpecification;

	public class IncidentManagementStepsimple2 {
		public static RequestSpecification inputRequest;
		public static Response response;
		
		
		@Given("User set the endpoint for service now application")
		public void setEndpoint() {
			
			RestAssured.baseURI = "https://dev62134.service-now.com/api/now/table/incident";
		}
		@And("User set the authentication for service now application")
		public void setAuth() {
			
			 inputRequest = RestAssured
					.given()
					.log()
					.all()
					.auth()
					.basic("admin", "Jl%Ay65ukN!T");
		}
		@And("User set the Queryparam in the Incident management request")	 
		
		public void setQueryparam() {
			inputRequest
			.queryParam("sysparm_fields", "sys_id, description, category, number");
			
		}
		@And("user set the request header in the Incident Managemnet request")
		public void setHeader() {
			
			inputRequest
			.contentType(ContentType.JSON)
			.accept(ContentType.JSON);
		}
		@When("user sends a post request body to the servie now application")
		public void sendPostRequest() {
		 File inputFile  = new File("./src/main/resources/CreateIncident.json");
			inputRequest.body(inputFile);
			Response response = inputRequest.post();
			response = inputRequest.when().post();
			response.then().log().all();
		}
		@Then("verify status code for the Incident Managemnet response")
		public void veriftyStatusCode() {
			
			response.then().assertThat().statusCode(200);
		}
		
		@And("Validate the sys_id in the Incident Management response")
		public void validateSysID() {
			
			response.jsonPath().get("results.sys_id");
			System.out.println("Sys_ID for the request: ");
		}
					
			
			
		}
		
		




