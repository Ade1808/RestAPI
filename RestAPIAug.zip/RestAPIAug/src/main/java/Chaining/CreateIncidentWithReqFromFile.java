package Chaining;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncidentWithReqFromFile extends BaseRestImpl {
	
	@Test
	public void sendPostBody() {
		

File inputFile  = new File("./src/main/resources/CreateIncident.json");
		
		inputRequest
		.queryParam("sysparm_fields", "sys_id, description, category, number")
		.contentType(ContentType.JSON)
		.accept(ContentType.JSON)
		.body(inputFile);
		
		
		Response response = inputRequest.post();
		response.prettyPrint();
		System.out.println(response.statusCode());
		sys_id = response.jsonPath().get("results.sys_id");
		System.out.print("Sys_ID" + sys_id);
	}


}
