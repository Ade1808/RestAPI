package Chaining;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetRequestWithMultipleQueryParameters extends BaseRestImpl {
	@Test(dependsOnGroups = "chaining.")
	public void sendGetRequest() {
		
		
	
		
		Map<String, String> queryMap = new HashMap<String, String>();
		queryMap.put("sysparm_fields", "sys_id, description, category, number");
		queryMap.put("category", "software");
		
		 inputRequest
		
		.queryParams(queryMap)
		.accept(ContentType.JSON);
		
		Response  response = inputRequest.get();
		response.prettyPrint();
		System.out.println("Status Code:" + response.statusCode());
		
		List<String> allSysID = response.jsonPath().getList("result.sys_id");
		// Index know but value is partially known
		response.then().assertThat().body("result[0].number", Matchers.containsString("INC"));
		
		// Value is known but no th index
		response.then().assertThat().body("result.sys_id", Matchers.hasItem("d446739d1bfd11104b168559cc4bcbce"));
		
		// Value is know and also in the index
		
		response.then().assertThat().body("result[1].sys_id",Matchers.equalTo("46c88ac1a9fe1981014de1c831fbcf6d") );
	}

}
