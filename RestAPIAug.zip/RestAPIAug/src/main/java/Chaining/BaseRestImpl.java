package Chaining;

import org.testng.annotations.BeforeTest;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;

public class BaseRestImpl {
	
	public static RequestSpecification inputRequest;
	public static String sys_id;
	@BeforeTest
	public void preConfig() {
		
		RestAssured.baseURI = "https://dev62134.service-now.com/api/now/table/incident";
		
		 inputRequest = RestAssured
				.given()
				.log()
				.all()
				.auth()
				.basic("admin", "Jl%Ay65ukN!T");
				
	}

}
