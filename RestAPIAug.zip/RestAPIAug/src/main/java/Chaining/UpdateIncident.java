package Chaining;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UpdateIncident extends BaseRestImpl {
	@Test(dependsOnMethods = "chaining.CreateIncidentWithReqFromFile.sendPostBody")
	public void sendUpdateRequest() {
		
		inputRequest
		.queryParam("sysparm_fields", "sys_id, description, category, number")
		.contentType(ContentType.JSON)
		.accept(ContentType.JSON)
		.body("{\"description\":\"This issue is not from DBMS. The connectivity needs fix\",\"category\":\"Hardware\"}");
		
		Response response = inputRequest.put("sys_id");
		response.then().log().all();
		
	}

}
