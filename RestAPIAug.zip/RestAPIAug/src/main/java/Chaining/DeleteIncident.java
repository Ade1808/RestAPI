package Chaining;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class DeleteIncident extends BaseRestImpl {
	@Test(dependsOnMethods = "chianing.UpdateIncident.sendUpdateRequest")
	public void DeleteRequest() {
		
				
				Response response = inputRequest.delete("sys_id");
				response.then().assertThat().statusCode(404);
				response.then().log().all();
	}

}
